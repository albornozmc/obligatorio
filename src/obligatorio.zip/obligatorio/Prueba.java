package obligatorio;

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *  MARIANO ALBORNOZ 357964
 *  MAURICIO PEREZ
 */

public class Prueba {
        public static void main(String[] args) throws Exception{
            //SE IMPRIMEN CORRECTAMENTE LOS CARACTERES
            System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8.name()));
            Sistema sistema = new Sistema();
            Scanner in = new Scanner(System.in);
            String opcion = "";
            
            while(!opcion.equals("0")){
                System.out.println();
                System.out.println("---------MENU---------");
                System.out.println(" 1) Informacion de autores");
                System.out.println(" 2) Registrar diseñador");
                System.out.println(" 3) Registrar ficha");
                System.out.println(" 4) Creacion del mural");
                System.out.println(" 5) Modificar el mural");
                System.out.println(" 6) Visualizar mural");
                System.out.println(" 7) Listado de disenadores");
                System.out.println(" 8) Comparador de similitudes");
                System.out.println(" 9) Visualizar todas las fichas");
                System.out.println(" 0) Terminar");
                System.out.print("Opcion: ");
                opcion = in.nextLine();
                
                    if(opcion.equals("0")){
                        System.out.println("Fin del programa");
                        
                    //INFO DE AUTORES    
                    }else if(opcion.equals("1")){
                        System.out.println("MARIANO ALBORNOZ - 357964");
                        System.out.println("MAURICIO PEREZ - ");
                        
                    //REGISTRO DE DISENADOR    
                    }else if(opcion.equals("2")){
                        String nombre = "";
                        boolean ok = false;
                        while(!ok){
                            System.out.print("Ingrese nombre del disenador");
                            nombre = in.nextLine();
                            if(nombre.length() == 0){
                                System.out.println("No puede ser vacio");
                            }else if(sistema.existeDisenador(nombre)){
                                System.out.println("Ya existe un disenador con ese nombre");
                            }else{
                                ok = true;
                            }
                        }
                        System.out.print("Ingrese su direccion");
                        String direccion = in.nextLine();
                        System.out.print("Ingrese su mail");
                        String mail = in.nextLine();
                        
                        sistema.agregarDisenador(new Disenador(nombre, direccion, mail));
                        System.out.println("Disenador registrado");
                        
                        //REGISTRO DE FICHA
                        }else if(opcion.equals("3")){
                            String nombre = "";
                            boolean ok = false;
                            while(!ok){
                                System.out.println("Ingrese nombre de la ficha: ");
                            
                                    nombre = in.nextLine().toUpperCase();
                                    if(nombre.length() == 0){
                                        System.out.println("El nombre no puede ser vacio");
                                    }else if(sistema.existeFicha(nombre)){
                                        System.out.println("Ya existe una ficha con ese nombre");
                                    }else{
                                    ok = true;
                                }   
                            }
                        //COLOR
                        char color = 'B';
                        ok = false;
                        while(!ok){
                            System.out.print("Color (R, A, B, N, M, V, G, C)");
                            String texto = in.nextLine().toUpperCase();
                                if(texto.length() == 1 && sistema.colorValido(texto.charAt(0))){
                                    color = texto.charAt(0);
                                    ok = true;
                                }else{
                                    System.out.println("El color es incorrecto");
                                }
                            }
                        
                        //DISEÑO CHICO DE LA FICHA
                        String chico = "";
                        ok = false;
                        while(!ok){
                            System.out.print("Diseno chico");
                            chico = in.nextLine();
                                if(chico.length() == 9){
                                    ok = true;
                                }else{
                                    System.out.println("Debe tener 9 caracteres");
                                }
                            }
                        
                        //DISEÑO GRANDE DE FICHA
                        String grande = "";
                        ok = false;
                        while(!ok){
                            System.out.println("Diseno grande");
                            grande = in.nextLine();
                                if(grande.length() == 25){
                                    ok = true;
                                }else{
                                    System.out.println("Debe tener 25 caracteres");
                                }
                            }
                        sistema.agregarFicha(new Ficha(nombre, color, chico, grande));
                        System.out.println("Ficha registrada");
                    
                    //CREACION DEL MURAL
                    }else if(opcion.equals("4")){
                        crearMural(sistema, in);
                    
                    //MODIFICAR EL MURAL
                    }else if(opcion.equals("5")){
                        modificarMural(sistema, in);
                        
                    //VISUALIZAR MURAL
                    }else if(opcion.equals("6")){
                        visualizarMural(sistema, in);
                        
                    //LISTADO DE DISENADORES
                    }else if(opcion.equals("7")){
                        listarDisenadores(sistema);
                        
                    //COMPARAR SIMILITUDES
                    }else if(opcion.equals("8")){
                        compararMurales(sistema, in);      
                    
                    //VISUALIZAR TODAS LAS FICHAS
                    }else if(opcion.equals("9")){
                        for(Ficha f : sistema.getFichas()){
                            System.out.println("Ficha: " + f.getNombre());
                            System.out.println("Color: " + f.getColor());
                                System.out.println("Tamano chico:");
                                    for(int i = 0; i < 3;i++){
                                        System.out.println(f.getCodigoAnsi() + f.getLinea(3, i) + "\u001B[0m");
                                    }
                                System.out.println("Tamno grande");
                                    for(int i = 0; i < 5;i++){
                                        System.out.println(f.getCodigoAnsi() + f.getLinea(5, i) + "\u001B[0m");
                                    }
                                    System.out.println();
                                }
                    }else{
                        System.out.println("Opcion invalida");
                    }
                }
            }
        
        
        //CREACION DEL MURAL
        public static void crearMural(Sistema sistema, Scanner in){
                if(sistema.getDisenadores().size() == 0){
                    System.out.println("Se debe registrar un disenador");
                //DISENADOR
                }else{
                    System.out.println("Disenadores registrados");
                    for(Disenador d : sistema.getDisenadores()){
                        System.out.println(" - " + d.getNombre());
                    }
                    Disenador disenador = null;
                    while(disenador == null){
                        System.out.print("Nombre del disenador:");
                        disenador = sistema.buscarDisenador(in.nextLine());
                        if(disenador == null){
                            System.out.println(("No exister disenador con ese nombre"));
                        }
                    }
                    //NOMBRE DEL MURAL
                    String nombre = "";
                    boolean ok = false;
                    while(!ok){
                        System.out.print("Nombre del mural");
                        nombre = in.nextLine();
                        if(nombre.length() == 0){
                            System.out.println("No puede tener nombre vacio");
                        }else if(sistema.existeMural(nombre)){
                            System.out.println("Ya existe un mural con ese nombre");
                        }else{
                            ok = true;
                        }
                    }
                    //FORMATO
                    String formato = "";
                    ok = false;
                    while(!ok){
                        System.out.print("Elija formato (D : DAMERO, R: RANDOM, F: FILAS, B: BORDE, M: MANUAL)");
                        formato = in.nextLine().toUpperCase();
                        if(formato.equals("D") || formato.equals("R") || formato.equals("F") || formato.equals("B") || formato.equals("M")){
                            ok = true;
                        }else{
                            System.out.println("Formato invalido");
                        }
                    }
                    //DOS FICHAS(DISTINTAS)
                    System.out.println("Fichas registradas");
                    for(Ficha f : sistema.getFichas()){
                        System.out.println(" - " + f.getNombre());
                    }
                    Ficha f1 = null;
                    while(f1 == null){
                        System.out.print("Ingrese nombre de la primer ficha");
                        f1 = sistema.buscarFicha(in.nextLine().toUpperCase());
                            if(f1 == null){
                                System.out.println("No existe una ficha con ese nombre");
                            }
                    }
                    Ficha f2 = null;
                    while(f2 == null){
                        System.out.println("Ingrese nombre de la segunda ficha");
                        f2 = sistema.buscarFicha(in.nextLine().toUpperCase());
                        if(f2 == null){
                            System.out.println("No existe ficha con ese nombre");
                        }else if(f2.getNombre().equals(f1.getNombre())){
                            System.out.println("Debe ser una ficha distinta a la primera");
                            f2 = null;
                        }
                    }
                    Mural mural = new Mural(nombre, disenador, formato, f1, f2, sistema.buscarFicha("VACIA"));
                    
                    //MURAL MANUAL
                    if(formato.equals("M")){
                        boolean sigue = true;
                        while(sigue){
                            System.out.print("Agrega una ficha? Responda con S/N");
                            String resp = in.nextLine().toUpperCase();
                            if(resp.equals("S")){
                                int fila = pedirNumero(in, "Fila (1 a 10) ", 10);
                                int columna = pedirNumero(in, "Columna (1 a 12): ", 12);
                                int cual = pedirNumero(in, "Ficha (1: " + f1.getNombre() + ", 2: " + f2.getNombre() + "): ", 2);
                                    if(cual == 1){
                                        mural.colocar(fila,columna,f1);
                                    }else{
                                        mural.colocar(fila,columna,f2);
                                        }
                                    }else if(resp.equals("N")){
                                            sigue = false;
                                            }else{
                                        System.out.println("Responda S o N");
                            }
                        }
                        //ORIGINAL
                        mural.guardarOriginal();
                    }
                    disenador.agregarMural(mural);
                    System.out.println("Mural registrado");
                    System.out.println("Tamano grande:");
                    System.out.println(mural.visualizar(5));
                    System.out.println("Tamano chico");
                    System.out.println(mural.visualizar(3));
                }
            }
        
        //PEDIR NUMERO
        public static int pedirNumero(Scanner in, String mensaje, int max){
            int numero = 0;
            while(numero == 0){
                System.out.print(mensaje);
                String texto = in.nextLine();
                for(int i = 1; i <= max ;i++){
                    if(texto.equals(String.valueOf(i))){
                        numero = i;
                    }
                }
                if(numero == 0){
                    System.out.println("Debe ingresar un numero entre 1 y " + max);
                }
            }
            return numero;
            }
        
        //MODIFICAR MURAL
        public static void modificarMural(Sistema sistema, Scanner in){
            if(sistema.getMurales().size() == 0){
                System.out.println("No hay murales");
            }else{
                System.out.println("Murales regustrados");
                for(Mural m : sistema.getMurales()){
                    System.out.println(" - " + m.getNombre() + " (disenador : " + m.getDisenador().getNombre() + ")");
                }
                Mural mural = null;
                while(mural == null){
                    System.out.print("Ingrese nombre del mural  ");
                    mural = sistema.buscarMural(in.nextLine());
                    if(mural == null){
                        System.out.println("No existe mural con ese nombre");
                    }
                }
                String sub = "";
                while(!sub.equals("0")){
                    System.out.println();
                    System.out.println("1) Modificar posicion");
                    System.out.println("2) Modificar ficha");
                    System.out.println("3) Restaurar");
                    System.out.println("0) Volver");
                    System.out.print("Opcion: ");
                    sub = in.nextLine();
                    
                    if(sub.equals("1")){
                        int fila = pedirNumero(in, "Fila (1 a 10)", 10);
                        int columna = pedirNumero(in, "Columna(1 a 12)", 12);
                        System.out.println("Fichas registradas");
                        for(Ficha f : sistema.getFichas()){
                            System.out.println(" - " + f.getNombre());
                        }
                        Ficha nueva = null;
                        while(nueva == null){
                            System.out.println("Ingrese nombre de la ficha");
                            nueva = sistema.buscarFicha(in.nextLine().toUpperCase());
                            if(nueva == null){
                                System.out.println("No existe ficha con ese nombre");
                            }
                        }
                        mural.colocar(fila, columna, nueva);
                        mostrarMural(mural);
                    }else if(sub.equals("2")){
                        ArrayList<Ficha> usadas = mural.fichasUsadas();
                        System.out.println("Fichas del mural");
                        for(Ficha f : usadas){
                            System.out.println(" - " + f.getNombre());
                        }
                        Ficha vieja = null;
                        while(vieja == null){
                            System.out.print("Ficha a reemplazar ");
                            String nombreVieja = in.nextLine().toUpperCase();
                            for(Ficha f : usadas){
                                if(f.getNombre().equals(nombreVieja)){
                                    vieja = f;
                                }
                            }
                            if(vieja == null){
                                System.out.println("Esa ficha no esta en el mural");
                            }
                        }
                        System.out.println("Fichas registradas");
                        for(Ficha f : sistema.getFichas()){
                            System.out.println(" - " + f.getNombre());
                        }
                        Ficha nueva = null;
                        while(nueva == null){
                            System.out.print("Ficha nueva");
                            nueva = sistema.buscarFicha(in.nextLine().toUpperCase());
                            if(nueva == null){
                                System.out.println("No existe ficha con ese nombre");
                            }
                        }
                        mural.reemplazarFicha(vieja, nueva);
                        mostrarMural(mural);
                        
                    }else if(!sub.equals("3")){
                        mural.restaurar();
                        mostrarMural(mural);
                        
                    }else if(!sub.equals("0")){
                        System.out.println("Opcion invalida");
                        }
                    }
                }
            }
        //MUESTRA MURAL EN AMBOS TAMANOS
        public static void mostrarMural(Mural mural){
            System.out.println("Tamano grande");
            System.out.println(mural.visualizar(5));
            System.out.println("Tamano chico");
            System.out.println(mural.visualizar(3));
            }
        
        //VISUALIZAR MURAL
        public static void visualizarMural(Sistema sistema, Scanner in){
            if(sistema.getDisenadores().size() == 0){
            System.out.println("No hay disenadores registrados");
        }else{
                System.out.println("Disenadores registrados");
                for(Disenador d : sistema.getDisenadores()){
                    System.out.println(" - " + d.getNombre());
                }
                Disenador disenador = null;
                while(disenador == null){
                    System.out.print("Ingrese nombre del disenador");
                    disenador = sistema.buscarDisenador(in.nextLine());
                    if(disenador == null){
                        System.out.println("No existe ningun disenador con ese nombre");
                    }
                }
                if(disenador.getMurales().size() == 0 ){
                    System.out.println("El disenador no tiene murales");
                }else{
                    System.out.println("Murales de " + disenador.getNombre());
                    for(Mural m : disenador.getMurales()){
                        System.out.println(" - " + m.getNombre());
                    }
                    Mural mural = null;
                    while(mural == null){
                        System.out.print("Ingrese nombre de mural");
                        String nombreMural = in.nextLine();
                        for(Mural m : disenador.getMurales()){
                            if(m.getNombre().equals(nombreMural)){
                                mural = m;
                            }
                        }
                        if(mural == null){
                            System.out.println("El disenador no tiene mural con ese nombre");
                        }
                    }
                    //FORMATO INICIAL
                    int tamano = 0;
                    while(tamano == 0){
                        System.out.print("Ingrese formato(C:Chico, G:Grande)");
                        String formato = in.nextLine().toUpperCase();
                        if(formato.equals("C")){
                            tamano = 3;
                        }else if(formato.equals("G")){
                            tamano = 5;
                        }else{
                            System.out.println("Formato invalido");
                        }
                    }
                    //ALTERNA TAMANO
                    boolean sigue = true;
                    boolean dibujar = true;
                    while(sigue){
                        if(dibujar){
                            System.out.println(mural.visualizar(tamano));
                        }
                        System.out.print("Presione enter para cambiar de tamano, S para salir");
                        String resp = in.nextLine().toUpperCase();
                        if(resp.equals("S")){
                            sigue = false;
                        }else if(resp.length() == 0){
                            if(tamano == 3){
                                tamano = 5;
                            }else{
                                tamano = 3;
                            }
                            dibujar = true;
                        }else{
                            System.out.println("Opcion invalida");
                            dibujar = false;
                            }
                        }
                    }
                }
            }
        
        //LISTADO DE DISENADORES
        public static void listarDisenadores(Sistema sistema){
            if(sistema.getDisenadores().size() == 0){
                System.out.println("No hay disenadores registrados");
            }else{
                Disenador[] orden = new Disenador[sistema.getDisenadores().size()];
                for(int i = 0; i < orden.length;i++){
                    orden[i] = sistema.getDisenadores().get(i);
                }
                for(int i = 0; i < orden.length - 1;i++){
                    for(int j = 0; j < orden.length - 1;j++){
                        String a  = orden[j].getNombre().toLowerCase();
                        String b = orden[j+1].getNombre().toLowerCase();
                        if(a.compareTo(b) > 0){
                            Disenador aux = orden[j];
                            orden[j] = orden[j+1];
                            orden[j+1] = aux;
                        }
                    }
                }
                for(Disenador d : orden){
                    System.out.println("Disenador " + d.getNombre());
                    System.out.println("Direccion " + d.getDireccion());
                    System.out.println("Mail " + d.getMail());
                    System.out.println("Cantidad de murales " + d.getMurales().size());
                    System.out.println("Cantidad de fichas diferentes " + d.fichasDiferentes().size());
                    System.out.println("Cantidad de colores diferentes " + d.cantidadColores());
                    System.out.println();
                }
            }
        }
        //COMPARADOR SIMILITUDES
        public static void compararMurales(Sistema sistema, Scanner in){
            if(sistema.getMurales().size() == 0){
                System.out.println("No hay murales");
            }else{
                System.out.println("Murales registrados");
                for(Mural m : sistema.getMurales()){
                    System.out.println(" - " + m.getNombre() + " (disenador " + m.getDisenador().getNombre() + ")");
                }
                Mural original = null;
                while(original == null){
                    System.out.print("Ingrese el nombre del mural");
                    original = sistema.buscarMural(in.nextLine());
                    if(original == null){
                        System.out.println("No existe mural con ese nombre");
                    }
                }
                
                int fila = pedirNumero(in, "Fila inicial(1 a 10) ",10);
                int columna = pedirNumero(in, "Columna inicial(1 a 12", 12);
                int filas = pedirNumero(in, "Cantidad de filas(1 a " + (10-fila+1) + ")", 10-fila+1);
                int columnas = pedirNumero(in, "Cantidad de columnas(1 a " + (12-columna+1) + ")", 12-columna+1);
                
                int cantidad = 0;
                for(Mural otro : sistema.getMurales()){
                    if(!otro.getNombre().equals(original.getNombre())){
                        int[] posicion = otro.buscarArea(original, fila, columna, filas, columnas);
                        if(posicion != null){
                            System.out.println("Mural " + otro.getNombre() + " (disenador " + otro.getDisenador().getNombre() + ") fila " + posicion[0] + ", columna " + posicion[1]);
                            cantidad++;
                        }
                    }
                }
                if(cantidad == 0){
                    System.out.println("Ningun mural tiene area semejante");
                }
            }
        }
    }
