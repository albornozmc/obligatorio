package obligatorio;

/**
 * MARIANO ALBORNOZ 357964
 * MAURiCIO PEREZ
 */
public class Ficha {
    
    //CREACION DE FICHA
        private String nombre;
        private char color;
        private char[][] chico;
        private char[][] grande;
        
        public Ficha(String nombre, char color, String matChica, String matGrande){
            
            this.nombre = nombre;
            this.color = color;
            this.chico = armadoMatriz(matChica, 3);
            this.grande = armadoMatriz(matGrande, 5);
        }
        
        // ARMADO DE MATRIZ
        private char[][] armadoMatriz(String texto, int n){
            char[][] m = new char[n][n];
            for(int i = 0; i < n; i++){
                for(int j = 0; j < n;j++){
                    char c = texto.charAt(i*n+j);
                    m[i][j] = (c == '.') ? ' ' :c;
                }
            }
            return m;
        }
    
    // CONSULTAS
    
    public String getNombre(){
        return nombre;
    }
    
    public char getColor(){
        return color;
    }
    
    //CONSULTA DE COLOR
    public String getCodigoAnsi(){
        String codigo = "\u001B[30m"; //negro
            if(color == 'R'){
                codigo = "\u001B[31m"; //rojo
            }else if(color == 'V'){
                codigo = "\u001B[32m"; //verde
            }else if(color == 'M'){
                codigo = "\u001B[33m"; //amarillo
            }else if(color == 'A'){
                codigo = "\u001B[34m"; //azul
            }else if(color == 'G'){
                codigo = "\u001B[35m"; //magenta
            }else if(color == 'C'){
                codigo = "\u001B[36m"; //celeste
            }else if(color == 'B'){
                codigo = "\u001B[37m"; //blanco
            }
            return codigo;
        }
    
    //DEVUELVE FILA DEL DIESENO
    public String getLinea(int tamano, int fila){
        char[][] m = (tamano == 3) ? chico : grande;
        return new String(m[fila]);
    }
}

