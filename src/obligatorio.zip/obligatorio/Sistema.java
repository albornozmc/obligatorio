package obligatorio;
import java.util.ArrayList;

/**
 * MARIANO ALBORNOZ 357964
 * MAURICIO PEREZ 
 */
public class Sistema {
        private ArrayList<Ficha> fichas;
        private ArrayList<Disenador> disenadores;
        
        public Sistema(){
            this.fichas = new ArrayList<Ficha>();
            this.disenadores = new ArrayList<Disenador>();
            this.precargarFichas();
        }
        
        private void precargarFichas() {
            
        fichas.add(new Ficha("SOL", 'M',
                "\\|/-*-/|\\",
                "..|...\\|/.--*--./|\\...|.."));
        
        fichas.add(new Ficha("CUADRADO", 'N',
                "+-+|.|+-+",
                "+---+|...||...||...|+---+"));
        
        fichas.add(new Ficha("CORAZON", 'R',
                "*.****.*.",
                "**.************.***...*.."));
        
        fichas.add(new Ficha("COPA", 'C',
                "\\./.|./_\\",
                "\\.../.\\./...|....|.../_\\."));
        
        fichas.add(new Ficha("ARBOL", 'V',
                ".^.^^^.|.",
                "..^...^^^.^^^^^..|.../.\\."));
        
        fichas.add(new Ficha("GATO", 'A',
                "^.^o.o=^=",
                "/\\_/\\(o.o).>^<../|\\../.\\."));
        
        fichas.add(new Ficha("DIAMANTE", 'G',
                ".*.*.*.*.",
                "..*...*.*.*...*.*.*...*.."));
        
        fichas.add(new Ficha("VACIA", 'B',
                ".........",
                "........................."));
    }
        public ArrayList<Ficha> getFichas(){
            return fichas;
        }
        public ArrayList<Disenador> getDisenadores(){
            return disenadores;
        }
        
        //VALIDACIONES
        
        public boolean colorValido(char c){
            return "RABNMVGC".indexOf(c) >= 0;
        }
        
        public boolean existeFicha(String nombre){
            boolean existe = false;
            for(Ficha f : fichas ){
                if(f.getNombre().equals(nombre)){
                    existe = true;
                }
            }
            return existe;
        }
        
        //OPERACIONES
        public void agregarFicha(Ficha f){
            fichas.add(f);
        }
        
        //COMPARA NOMBRE
        public boolean existeDisenador(String nombre){
            boolean existe = false;
            for(Disenador d : disenadores){
                if(d.getNombre().equals(nombre)){
                    existe = true;
                }
            }
            return existe;
        }
        
        public void agregarDisenador(Disenador d){
            disenadores.add(d);
        }
        
        //BUSQUEDA FICHAS
        public Ficha buscarFicha(String nombre){
            Ficha buscada = null;
            for(Ficha f : fichas){
                if(f.getNombre().equals(nombre)){
                    buscada = f;
                }
            }
            return buscada;
        }
        //BUSQUEDA DISENADOR
        public Disenador buscarDisenador(String nombre){
            Disenador buscado = null;
            for(Disenador d : disenadores){
                if(d.getNombre().equals(nombre)){
                    buscado = d;
                }
            }
            return buscado;
        }
        //VALDIAR MURAL UNICO
        public boolean existeMural(String nombre){
            boolean existe = false;
            for(Disenador d : disenadores){
                for(Mural m : d.getMurales()){
                    if(m.getNombre().equals(nombre)){
                        existe = true;
                    }
                }
            }
            return existe;
        }
        
    //DEVUELVE MURALES DE TODOS LOS DISENADORES
        public ArrayList<Mural> getMurales(){
            ArrayList<Mural> todos = new ArrayList<Mural>();
            for(Disenador d : disenadores){
                for(Mural m : d.getMurales()){
                    todos.add(m);
                }
            }
            return todos;
        }
    //BUSQUEDA MURAL
        public Mural buscarMural(String nombre){
            Mural buscado = null;
            for(Mural m : getMurales()){
                if(m.getNombre().equals(nombre)){
                    buscado = m;
                }
            }
            return buscado;
        }
    }
